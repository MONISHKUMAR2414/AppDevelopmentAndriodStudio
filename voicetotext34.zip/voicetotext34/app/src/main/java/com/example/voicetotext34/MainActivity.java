package com.example.voicetotext34;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private boolean permissionToRecordAccepted = false;
    private String[] permissions = {Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private AudioRecord audioRecord;
    private boolean isRecording = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnRecord = findViewById(R.id.btnRecord);
        Button btnStop = findViewById(R.id.btnStop);

        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);

        btnRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startRecording();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopRecording();
            }
        });
    }

    private void startRecording() {
        int sampleRate = 16000; // Sample rate in Hz
        int bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize);

        audioRecord.startRecording();
        isRecording = true;

        new Thread(() -> {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            byte[] buffer = new byte[bufferSize];
            while (isRecording) {
                int read = audioRecord.read(buffer, 0, buffer.length);
                if (read > 0) {
                    outputStream.write(buffer, 0, read);
                }
            }

            // Convert raw audio to WAV and save it
            byte[] audioData = outputStream.toByteArray();
            saveAsWav(audioData, sampleRate);
        }).start();
    }

    private void stopRecording() {
        isRecording = false;
        if (audioRecord != null) {
            audioRecord.stop();
            audioRecord.release();
            audioRecord = null;
        }
    }

    private void saveAsWav(byte[] audioData, int sampleRate) {
        File wavFile = new File(Environment.getExternalStorageDirectory(), "recording.wav");
        try (FileOutputStream fos = new FileOutputStream(wavFile)) {
            byte[] wavHeader = createWavHeader(audioData.length, sampleRate);
            fos.write(wavHeader);
            fos.write(audioData);
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Audio saved as WAV", Toast.LENGTH_SHORT).show());
        } catch (IOException e) {
            e.printStackTrace();
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error saving audio", Toast.LENGTH_SHORT).show());
        }
    }

    private byte[] createWavHeader(int totalAudioLen, int sampleRate) {
        int channels = 1; // Mono
        int byteRate = 16 * sampleRate * channels / 8;

        byte[] header = new byte[44];
        header[0] = 'R'; header[1] = 'I'; header[2] = 'F'; header[3] = 'F';
        header[4] = (byte) (totalAudioLen + 36);
        header[5] = (byte) ((totalAudioLen + 36) >> 8);
        header[6] = (byte) ((totalAudioLen + 36) >> 16);
        header[7] = (byte) ((totalAudioLen + 36) >> 24);
        header[8] = 'W'; header[9] = 'A'; header[10] = 'V'; header[11] = 'E';
        header[12] = 'f'; header[13] = 'm'; header[14] = 't'; header[15] = ' ';
        header[16] = 16; // subchunk1 size (for PCM)
        header[17] = 0; header[18] = 0; header[19] = 0;
        header[20] = 1; // audio format (1 for PCM)
        header[21] = 0;
        header[22] = (byte) channels; // number of channels
        header[23] = 0;
        header[24] = (byte) sampleRate; // sample rate
        header[25] = (byte) (sampleRate >> 8);
        header[26] = (byte) (sampleRate >> 16);
        header[27] = (byte) (sampleRate >> 24);
        header[28] = (byte) byteRate; // byte rate
        header[29] = (byte) (byteRate >> 8);
        header[30] = (byte) (byteRate >> 16);
        header[31] = (byte) (byteRate >> 24);
        header[32] = (byte) (channels * 16 / 8); // block align
        header[33] = 0;
        header[34] = 16; // bits per sample
        header[35] = 0;
        header[36] = 'd'; header[37] = 'a'; header[38] = 't'; header[39] = 'a';
        header[40] = (byte) totalAudioLen;
        header[41] = (byte) (totalAudioLen >> 8);
        header[42] = (byte) (totalAudioLen >> 16);
        header[43] = (byte) (totalAudioLen >> 24);
        return header;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permissionToRecordAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (!permissionToRecordAccepted) finish();
    }
}
